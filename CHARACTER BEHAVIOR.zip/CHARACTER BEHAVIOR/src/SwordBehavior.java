public class SwordBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("I swing with a sword");
    }
}
