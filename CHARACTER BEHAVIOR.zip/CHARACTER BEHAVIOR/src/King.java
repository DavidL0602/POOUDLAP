public class King extends Character {
    public  King(){
        wp= new SwordBehavior();
    }
    public void display(){
        System.out.println("I´m King");

    }
    public void fight() {
        System.out.println("I fight as a King");
    }
}
