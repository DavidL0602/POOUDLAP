public class AxeBehavior implements WeaponBehavior{

    public void useWeapon() {
   System.out.println("I Chop with an axe");
    }
}
