public class Knight extends Character {
    public  Knight(){
        wp= new KnifeBehavior();
    }
    public void display(){
        System.out.println("I´m Knight");

    }
    public void fight() {
        System.out.println("I fight as a Knight");
    }
}
