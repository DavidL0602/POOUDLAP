public class BowAndArrowBehavior implements WeaponBehavior{
    public void useWeapon() {
        System.out.println("I shoot with Bow and Arrow");

    }
}
