public interface WeaponBehavior {
    public void useWeapon();
}
