public class Queen extends Character {
    public  Queen(){
        wp= new BowAndArrowBehavior();
    }
    public void display(){
        System.out.println("I´m Queen");

    }
    public void fight() {
        System.out.println("I fight as a Queen");
    }
}
