public class KnifeBehavior implements WeaponBehavior{
    public void useWeapon(){
        System.out.println("I Cut with a knife");
    }

}
