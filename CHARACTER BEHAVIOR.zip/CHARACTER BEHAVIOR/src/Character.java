public abstract class Character {
    WeaponBehavior wp;

    public abstract void fight();
    public abstract void display();
    public void performWeapon(){
        wp.useWeapon();
    }
    public void walk(){
        System.out.println("I´m walking...");
    }
    public void crouch(){
        System.out.println("I can crouch...");
    }
    public void ShowCharacter(){
        display();
        fight();
        walk();
        crouch();
        performWeapon();
    }
    public void setWeaponBehavior(WeaponBehavior w){
        wp=w;
    }
}
