public class Troll extends Character {
    public  Troll(){
        wp= new AxeBehavior();
    }
    public void display(){
        System.out.println("I´m Troll");

    }
    public void fight() {
        System.out.println("I fight as a Troll");
    }
}
