class Main {
    public static void main(String[] args) {
        System.out.println("Action game");


        Character k, q, t, kn;
        k = new King();
        q = new Queen();
        t = new Troll();
        kn = new Knight();

        k.ShowCharacter();
        q.ShowCharacter();
        t.ShowCharacter();
        kn.ShowCharacter();

     k.setWeaponBehavior(new KnifeBehavior());
     k.ShowCharacter();
        k.setWeaponBehavior(new BowAndArrowBehavior());
        k.ShowCharacter();
        k.setWeaponBehavior(new AxeBehavior());
        k.ShowCharacter();
     q.setWeaponBehavior(new KnifeBehavior());
     q.ShowCharacter();
        q.setWeaponBehavior(new AxeBehavior());
        q.ShowCharacter();
        q.setWeaponBehavior(new SwordBehavior());
        q.ShowCharacter();
      t.setWeaponBehavior(new KnifeBehavior());
      t.ShowCharacter();
        t.setWeaponBehavior(new SwordBehavior());
        t.ShowCharacter();
        t.setWeaponBehavior(new BowAndArrowBehavior());
        t.ShowCharacter();
     kn.setWeaponBehavior(new SwordBehavior());
     kn.ShowCharacter();
        kn.setWeaponBehavior(new AxeBehavior());
        kn.ShowCharacter();
        kn.setWeaponBehavior(new BowAndArrowBehavior());
        kn.ShowCharacter();

    }
}